#!/bin/bash
#
# This script gathers information about the operation of the module
#

#Debug
# set -x
# set -u

# Get the location of this script
script_dir=`dirname $0`

#################################################
# Globals
PRODUCT=scaleio
COMPANY=emc
COMP_INS_PATH=/opt/$COMPANY/$PRODUCT
TMP_TARGET_PATH=/tmp/$PRODUCT-getinfo-tmp/`hostname`
EXT_TARGET_PATH=/tmp/$PRODUCT-getinfo-extra
OUT_TARGET_PATH=/tmp/$PRODUCT-getinfo
MDM_DIR_NAME=mdm

# Assign defaults
GENERATE_TGT_CORE=0
GENERATE_MDM_CORE=0
COPY_REP_FILES=0
EXCEPTIONS_ONLY=0
LIGHT_VERSION=0
COPY_VGCORE_DUMPS=0
COPY_CORE_DUMPS=0
COPY_BINARIES=0
EXTRACT_SDBG=1
FORCE_NOT_CONNECT=0
USERNAME=""
PASSWORD=""
SECURITY=""

PIDOF_BIN=$(which pidof)
IFCONFIG_BIN=$(which ifconfig)

#################################################
# Shared functions
#################################################

#################################################
# Run a CLI command with one or more arguments
run_cli_cmd()
{
	install_full_path=${COMP_INS_PATH}/${MDM_DIR_NAME}
	
	if [ -f $install_full_path/bin/run_cli.sh ]; then
		$install_full_path/bin/run_cli.sh $@ $SECURITY
	else
		$install_full_path/bin/cli $@ $SECURITY
	fi
}

#################################################
# Copy the logs directory
get_logs_dir()
{
	install_full_path=$1
	target_dir=$2
	if [ $LIGHT_VERSION -eq 1 ]; then
		mkdir $target_dir/logs
		if [ -e $install_full_path/logs/trc.0 ]; then
			\cp -rp "$install_full_path/logs/trc.0" $target_dir/logs/
		fi
		if [ -e $install_full_path/logs/exp.0 ]; then
			\cp -rp "$install_full_path/logs/exp.0" $target_dir/logs/
		fi
	else
		\cp -rp "$install_full_path/logs" $target_dir
	fi

	if [ -x $install_full_path/bin/showevents.py ] && 
           which python > /dev/null; then
            $install_full_path/bin/showevents.py -a |\
                  sed -r "s:\x1B\[[0-9;]*[mK]::g" > $target_dir/logs/events.txt
        elif [ -x $install_full_path/bin/showevents.sh ]; then
            $install_full_path/bin/showevents.sh --all --plain > $target_dir/logs/events.txt
        elif [ -f $COMP_INS_PATH/${MDM_DIR_NAME}/logs/eventlog.db ]; then
           # Theoretically unreachable
           cp $COMP_INS_PATH/${MDM_DIR_NAME}/logs/eventlog.db $target_dir/logs
	fi
}

#################################################
# Copy the cfg directory
get_cfg_dir()
{
   install_full_path=$1
   target_dir=$2

   \cp -rp "$install_full_path/cfg" $target_dir
}

#################################################
# Copy the exception files
get_exception_files()
{
   install_full_path=$1
   target_dir=$2
   if [ "`ls -l $install_full_path/logs/| awk '{print $NF}'|egrep -e ^exp| wc -l`" != "0" ]; then
		\cp -rp $install_full_path/logs/exp.* $target_dir
	fi
}

#################################################
# Copy core dump files
get_core_files()
{
   if [ $COPY_CORE_DUMPS -ne 0 ] ; then
       install_full_path=$1
       target_dir=$2
       proc_real_name=$3

      \mkdir -p $target_dir/bin
      \pushd $target_dir/bin
      \ls -lt ${install_full_path}/bin/core.* | head -n $COPY_CORE_DUMPS | awk '{print "cp " $9 " ./"}' | sh ;
      for core_file in $(ls core.* 2>/dev/null); do
          gdb ${install_full_path}/bin/${proc_real_name} $core_file -ex "thread apply all bt" -ex quit > ${core_file}.gdb_trace
      done
      \popd
   fi 
}
#################################################
# Copy vgcore dump files
get_vgcore_files()
{
   if [ $COPY_VGCORE_DUMPS -ne 0 ] ; then
       install_full_path=$1
       target_dir=$2
       proc_real_name=$3

      \mkdir -p $target_dir/bin
      \pushd $target_dir/bin
      \ls -lt ${install_full_path}/bin/vgcore.* | head -n $COPY_VGCORE_DUMPS | awk '{print "cp " $9 " ./"}' | sh ;
      \popd
   fi 
}

#################################################
# Copy the bin files
get_bin_file()
{
   if [ $COPY_BINARIES -ne 0 ] ; then
       install_full_path=$1
       target_dir=$2
       bin_file=$3
    
       \mkdir $target_dir/bin
       \cp -rp "$install_full_path/bin/$bin_file" $target_dir/bin/
   fi
}

#################################################
# Clean the temporary information gathered
clean_tmp_dir()
{
    echo Cleaning temporary information
    \rm -rf $TMP_TARGET_PATH
}

#################################################
# Handle interrupt signal by cleaning all temporary info
handle_interrupt()
{
    clean_tmp_dir
    trap - INT EXIT TERM
    exit 360
}

#################################################
# Print error to log
print_error()
{
	target_dir=$1
	error_str=$2

    echo "$error_str" | \tee -a "$target_dir/error_log"
}

#################################################
# Collect all information into a zipped TAR file
zip_and_tar_all()
{
	tar_path=$1
	tar_name=$2
	target_dir=$3

	if [ -d $TMP_TARGET_PATH ]; then
	    \mkdir -p $tar_path
	    if [ $? -ne 0 ]; then
	       echo "Unable to create directory $tar_path" | \tee /dev/stderr
	       exit 555
	    fi

        # Try to run the compression task with lower priority
    	nice /bin/tar -C $TMP_TARGET_PATH/.. -czf "$tar_path/$tar_name.tgz" .
    	if [ $? -eq 0 ]; then
	        echo "Archive $tar_path/$tar_name.tgz created successfully"
    	else
        	print_error $target_dir "Error creating archive $tar_path/$get_info_name.tgz"
    	fi
    else
    	echo "Can't find $TMP_TARGET_PATH"
    fi
}

#################################################
# Server functions
#################################################

#################################################
# Collect information about the server running the module
get_server_info()
{
    target_dir="$1/server"

    \mkdir $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    server_info_file="$target_dir/server_info.txt"

    echo Gathering server information

    echo date:								>  $server_info_file
    date					 	   		    >> $server_info_file

    echo         							>> $server_info_file
    echo uptime:							>> $server_info_file
    uptime      				 			>> $server_info_file

    echo         							>> $server_info_file
    echo ifconfig:							>> $server_info_file
    $IFCONFIG_BIN				 			>> $server_info_file

    echo         							>> $server_info_file
    echo uname:								>> $server_info_file
    uname -a								>> $server_info_file

    echo         							>> $server_info_file
    echo issue:								>> $server_info_file
    cat /etc/issue							>> $server_info_file
	
    echo         							>> $server_info_file
    echo df:								>> $server_info_file
    df -h								    >> $server_info_file

    echo         							>> $server_info_file
    echo $PRODUCT:							>> $server_info_file
    \ls -l /opt/$PRODUCT/					>> $server_info_file 2>/dev/null

    echo         							>> $server_info_file
    echo tmp:								>> $server_info_file
    \ls -l /tmp/        						>> $server_info_file

    echo         							>> $server_info_file
    echo whoami:							>> $server_info_file
    \whoami								    >> $server_info_file

    #Dump RPM package version if the system has RPM
    if which rpm > /dev/null; then
      echo         							>> $server_info_file
      echo rpm:    							>> $server_info_file
      rpm --nosignature -qa | \grep $PRODUCT	>> $server_info_file
    fi

    echo         							>> $server_info_file
    echo cpuinfo:       					>> $server_info_file
    \cat /proc/cpuinfo						>> $server_info_file

    echo                                    >> $server_info_file
    echo meminfo                            >> $server_info_file
    cat /proc/meminfo                       >> $server_info_file

    echo                                    >> $server_info_file
    echo shminfo                            >> $server_info_file
    sysctl kernel.shmall kernel.shmmax      >> $server_info_file

    echo                                    >> $server_info_file
    echo arpTableInfo                       >> $server_info_file
    sysctl net.ipv6.neigh.default net.ipv4.neigh.default >> $server_info_file

    echo                                    >> $server_info_file
    echo IOSchedlers                        >> $server_info_file
    grep . /sys/block/*/queue/scheduler     >> $server_info_file

    echo         							>> $server_info_file
    echo proc scini:       					>> $server_info_file
    \cat /proc/scini/*						>> $server_info_file 2>/dev/null
    
    echo         							>> $server_info_file
    echo scini:       					    >> $server_info_file
    ls -l /dev/disk/by-id | \grep scini     >> $server_info_file
    
    echo         							>> $server_info_file
    echo CPU, memory and SWAP usage:        >> $server_info_file
    top -bn 1 |head -5 |tail -3             >> $server_info_file

    \cp -p /var/log/messages* $target_dir 2>/dev/null

    if which journalctl > /dev/null 2>&1; then
        journalctl >> $target_dir/journalctl.log
    fi

    \cp -p /etc/lvm/lvm.conf $target_dir 2>/dev/null

    \cp -f /tmp/$PRODUCT*.log $target_dir 2>/dev/null
    
    \cp -p /etc/sysctl.conf $target_dir 2>/dev/null 
}

#################################################
# Sdbg functions
#################################################

# Generates an sdbg script that connects to a module
# and dumps list of screens
# parameters: 
#       - moduleName - the name of the module to connect
#       - scriptName - name of the output file (overwritten)
#       - port       - port for SDBG to connect
#       - <list of screens to dump>
generate_sdbg_script()
{
   local moduleName="$1"
   local scriptName="$2"
   local sdbgTargetIp="127.0.0.1"
   local sdbgPort="$3"


   rm -f "$scriptName"
   echo "connect $moduleName $sdbgTargetIp $sdbgPort"   >> "$scriptName"

   # shift to the number of the first screen to dump
   shift 3

   # loop over all required screens
   while (( "$#" )); do
       echo "dumpscreen $1"  >> "$scriptName"
       shift 1
   done

   echo "disconnect"    >> "$scriptName"
   echo "exit"          >> "$scriptName"
}



get_config_param()
{
    local installFullPath="$1"
    local paramName="$2"

    cat "$installFullPath/cfg/conf.txt" | grep "$paramName"| cut --delimiter='=' --fields=2
}


get_sdbg_screens()
{
    local install_full_path="$1"
    local target_dir="$2"
    local proc_base_name="$3"

    local sdbg_script_name="/tmp/sdbg.script"
    local sdbg_output_file="${target_dir}/sdgb_out.txt"

    if [ $EXTRACT_SDBG -eq 0 ] ; then
	    return;
    fi

   	\mkdir -p "$target_dir"
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    # Check SDBG is not already running
    sdbg_pid=$($PIDOF_BIN sdbg)

    if [ "$?" -eq "0" ]; then
        print_error $target_dir "Unable to collect information because an instance of the sdbg is already running"
	return
    fi

    # Get sdbg port
    if [ $proc_base_name != "sdc" ]; then
        local sdbg_port=`get_config_param "$install_full_path" sdbg_port`
        # Get SDBG info
        echo "Dumping sdbg info for $proc_base_name $sdbg_port"
    fi

    case "$proc_base_name" in 
        "sds")
            generate_sdbg_script tgt \
                "$sdbg_script_name" "$sdbg_port" \
                1 2 3 11 12 13 14 15 16 20 25 26 28
            ;;

        "mdm")
            generate_sdbg_script mdm \
                "$sdbg_script_name" "$sdbg_port" \
                1 2 3 7 8 9 10 17 18 20 21 22 23 24 27 28
            ;;

        "sdc")
            echo "Dumping sdbg info for $proc_base_name"
            generate_sdbg_script ini \
                "$sdbg_script_name" "" \
                1 4 5 6 28
            ;;

        "tb")
            generate_sdbg_script voter \
                "$sdbg_script_name" "" \
                1 2 3 21 28
            ;;

        *)
            print_error $target_dir "Failed to collect SDBG info, unexpected module $proc_base_name"
            return
            ;;
    esac

    $install_full_path/diag/sdbg "$sdbg_script_name" > "$sdbg_output_file"

    rm -f "$sdbg_script_name"
}


#################################################
# TGT functions
#################################################

#################################################
# Dump tgt info
tgt_dump_info()
{
    proc_full_name=$2 # sds, sds1, sds2
    target_dir="$1/$proc_full_name" # /tmp/$PRODUCT-getinfo-tmp-dir
    proc_base_name=$3 # sds

    install_full_path="$COMP_INS_PATH/$proc_full_name"

   	if [ ! -d $install_full_path ]; then
    	return 0
	fi
	proc_real_name=`cat $COMP_INS_PATH/$proc_full_name/bin/daemon`
    # Create a directory
    \mkdir -p $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    echo "Gathering information from $install_full_path"
	if [ $EXCEPTIONS_ONLY -eq 1 ]; then
		get_exception_files $install_full_path $target_dir
		return 0
	fi
    # Get logs and exception file
    get_logs_dir $install_full_path $target_dir
	get_cfg_dir  $install_full_path $target_dir
	get_bin_file $install_full_path $target_dir $proc_real_name
	get_core_files $install_full_path $target_dir $proc_real_name
	get_vgcore_files $install_full_path $target_dir $proc_real_name

    # Check if process is running to know if we can gather information
    process_pid=$($PIDOF_BIN $proc_real_name)

    if [ $? -eq 0 ]; then

    	# Get sdbg screens
    	get_sdbg_screens $install_full_path $target_dir $proc_base_name


    	# Generate a core file
        if [ $GENERATE_TGT_CORE -eq 1 ]; then
            hash gcore 2>&-
            if [ $? -eq 0 ]; then
                \gcore -o "$target_dir/runtime_generated_core" $process_pid
                gdb "$install_full_path/bin/$proc_real_name" "$target_dir/runtime_generated_core" -ex "thread apply all bt" -ex quit > $target_dir/runtime_generated_backtrace
            fi
        fi
    else
   		print_error $target_dir "$proc_full_name installed but not running"
    fi
}

#################################################
# MDM functions
#################################################

#################################################
# Get the main queries
mdm_cli_query()
{
	install_full_path=$1
	target_dir=$2

    local query_out_file="$target_dir/query_all.txt"
    rm -f "$query_out_file"

	if [ -f $install_full_path/bin/cli ]; then

    	run_cli_cmd --query_all --approve_certificate       >> "$query_out_file"
    	echo "===========================================================" >> "$query_out_file" 
    	run_cli_cmd --query_all_sds                         >> "$query_out_file" 
    	echo "===========================================================" >> "$query_out_file" 
    	run_cli_cmd --query_all_sdc                         >> "$query_out_file" 
    	echo "===========================================================" >> "$query_out_file" 
    	run_cli_cmd --query_all_volumes                     >> "$query_out_file" 
    	echo "===========================================================" >> "$query_out_file" 
    	run_cli_cmd --query_cluster --tech                  >> "$query_out_file" 
	else
   		print_error $target_dir "$install_full_path/bin/cli not found"
	fi
}




#################################################
# Get the throttler dump from the MDM
mdm_dump_throttler()
{
	local install_full_path=$1
	local target_dir=$2
	local mdm_pid=$3
	run_cli_cmd --debug_action --throt_dump \
                                --filename $target_dir/throt_dump.txt
}


#################################################
# Get the counters dump from the MDM
mdm_dump_v2c()
{
	local install_full_path=$1
	local target_dir=$2
	local mdm_pid=$3
	run_cli_cmd --debug_action --v2c_dump \
                                --filename $target_dir/v2c_dump.txt
}


#################################################
# Get the diagnostic counters from the MDM
mdm_dump_diag_cnt()
{
	local install_full_path=$1
	local target_dir=$2
	local mdm_pid=$3
	run_cli_cmd --query_diag_counters > $target_dir/diag_counters.txt
}


#################################################
# Get the counters dump from the MDM
mdm_dump_counters()
{
	local install_full_path=$1
	local target_dir=$2
	local mdm_pid=$3
	run_cli_cmd --debug_action --counters_dump \
                                --filename $target_dir/counters_dump.txt
}


#################################################
# Get the MultiHead manager dump from the SDBG
# Note: The file is dumped to the /tmp directory with the name multihead.<pid>
mdm_dump_multiheads()
{
	local install_full_path=$1
	local target_dir=$2
	local mdm_pid=$3
	run_cli_cmd --debug_action --multihead_dump \
                               --filename $target_dir/multihead_dump.txt
}

#################################################
# Get the Tgt Manager dump from the sdbg
# Note: The file is dumped to the /tmp directory with the name tgt.<pid>
mdm_dump_tgt_mgr()
{
	install_full_path=$1
	target_dir=$2
	mdm_pid=$3
	run_cli_cmd --debug_action --tgt_dump \
                               --filename $target_dir/tgt_dump.txt
}

#################################################
# Dump mdm info
mdm_dump_info()
{
    proc_full_name=$2 # mdm
    target_dir="$1/$proc_full_name" # /tmp/$PRODUCT-getinfo-tmp-dir/mdm
    proc_base_name=$2 # mdm

    install_full_path="$COMP_INS_PATH/$proc_full_name"

   	if [ ! -d $install_full_path ]; then
    	return 0
	fi
	proc_real_name=`cat $COMP_INS_PATH/$proc_full_name/bin/daemon`
    # Create a directory
    \mkdir -p $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    echo "Gathering information from $install_full_path"
	if [ $EXCEPTIONS_ONLY -eq 1 ]; then
		get_exception_files $install_full_path $target_dir
		return 0
	fi
    # Get logs and exception file
    get_logs_dir $install_full_path $target_dir
	get_cfg_dir  $install_full_path $target_dir
	get_bin_file $install_full_path $target_dir $proc_real_name
	get_core_files $install_full_path $target_dir $proc_real_name
	get_vgcore_files $install_full_path $target_dir $proc_real_name

	if [ $COPY_REP_FILES -eq 1 ]; then
		\cp $install_full_path/rep/*_rep.bin $target_dir 2> /dev/null
	fi

    # Check if process is running to know if we can gather information
    process_pid=$($PIDOF_BIN $proc_real_name)
    if [ $? -eq 0 ]; then

    	mdm_cli_query		$install_full_path $target_dir
    	mdm_dump_tgt_mgr 	$install_full_path $target_dir $process_pid
    	mdm_dump_multiheads $install_full_path $target_dir $process_pid
    	mdm_dump_counters   $install_full_path $target_dir $process_pid
    	mdm_dump_throttler  $install_full_path $target_dir $process_pid
    	mdm_dump_v2c        $install_full_path $target_dir $process_pid
    	mdm_dump_diag_cnt   $install_full_path $target_dir $process_pid


    	# Get sdbg screens
    	get_sdbg_screens $install_full_path $target_dir $proc_base_name

    	# Generate a core file
        if [ $GENERATE_MDM_CORE -eq 1 ]; then
            hash gcore 2>&-
            if [ $? -eq 0 ]; then
                \gcore -o "$target_dir/runtime_generated_core" $process_pid
                gdb "$install_full_path/bin/$proc_real_name" $target_dir/runtime_generated_core.* -ex "thread apply all bt" -ex quit > $target_dir/runtime_generated_backtrace
            fi
        fi
    else
   		print_error $target_dir "$proc_base_name installed but not running"
    fi
    
}


#################################################
# TB functions
#################################################

#################################################
# Dump tb sdbg screens
tb_dump_info()
{
    proc_full_name=$2
    target_dir="$1/$proc_full_name" # /tmp/$PRODUCT-getinfo-tmp-dir
	proc_base_name=$2

    install_full_path="$COMP_INS_PATH/$proc_full_name"


   	if [ ! -d $install_full_path ]; then
    	return 0
	fi
	proc_real_name=`cat $COMP_INS_PATH/$proc_full_name/bin/daemon`
    # Create a directory
    \mkdir -p $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    echo "Gathering information from $install_full_path"
	if [ $EXCEPTIONS_ONLY -eq 1 ]; then
		get_exception_files $install_full_path $target_dir
		return 0
	fi
    # Get logs and exception file
    get_logs_dir $install_full_path $target_dir
	get_cfg_dir  $install_full_path $target_dir
	get_bin_file $install_full_path $target_dir $proc_real_name
	get_core_files $install_full_path $target_dir $proc_real_name
	get_vgcore_files $install_full_path $target_dir $proc_real_name

	if [ $COPY_REP_FILES -eq 1 ]; then
		\cp $install_full_path/rep/*.rep $target_dir 2> /dev/null
	fi

	# Check if process is running to know if we can gather information
    process_pid=$($PIDOF_BIN $proc_real_name)
    if [ $process_pid -eq 0 ]; then
		print_error $target_dir "$proc_base_name installed but not running"
    else # Get sdbg screens
    	get_sdbg_screens $install_full_path $target_dir $proc_base_name
    fi
    
    if [ $COPY_CORE_DUMPS -ne 0 ] ; then
        pushd $target_dir
        ls -lt ${install_full_path}/bin/core.* | head -n $COPY_CORE_DUMPS | awk '{print "cp " $9 " ./"}' | sh ;
        popd
    fi 
}

#################################################
# INI functions
#################################################

#################################################
# Dump ini info
ini_dump_info()
{
    proc_full_name=$2
    target_dir="$1/$proc_full_name" # /tmp/$PRODUCT-getinfo-tmp-dir
    proc_base_name=$2

    install_full_path="$COMP_INS_PATH/$proc_full_name"

    if [ ! -d $install_full_path ]; then
    	return 0
    fi
    # Create a directory
    \mkdir -p $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    echo "Gathering information from $install_full_path"

    \cp /bin/$COMPANY/$PRODUCT/drv_cfg.txt $target_dir 2> /dev/null

    # Check if driver is running to know if we can gather SDBG information
    is_scini=`lsmod | grep scini | wc -l`
    if [ $is_scini -eq 0 ]; then
	    print_error $target_dir "$proc_base_name installed but not running"
    else 
    	# Get sdbg screens
    	get_sdbg_screens $install_full_path $target_dir $proc_base_name

        echo                                                      >> $target_dir/drv_cfg_queries.txt
    	echo version:                                             >> $target_dir/drv_cfg_queries.txt
    	$install_full_path/bin/drv_cfg --query_version            >> $target_dir/drv_cfg_queries.txt
    	        
        echo                                                      >> $target_dir/drv_cfg_queries.txt
    	echo query_diag_counters:                                 >> $target_dir/drv_cfg_queries.txt
    	$install_full_path/bin/drv_cfg --query_diag_counters      >> $target_dir/drv_cfg_queries.txt

        echo                                                      >> $target_dir/drv_cfg_queries.txt
    	echo query_mdms:                                          >> $target_dir/drv_cfg_queries.txt
    	$install_full_path/bin/drv_cfg --query_mdms               >> $target_dir/drv_cfg_queries.txt
    	
    	echo                                                      >> $target_dir/drv_cfg_queries.txt
    	echo query_vols:                                          >> $target_dir/drv_cfg_queries.txt
    	$install_full_path/bin/drv_cfg --query_vols               >> $target_dir/drv_cfg_queries.txt
    	
    	echo                                                      >> $target_dir/drv_cfg_queries.txt
    	echo query_tgts:                                          >> $target_dir/drv_cfg_queries.txt
    	$install_full_path/bin/drv_cfg --query_tgts --tech        >> $target_dir/drv_cfg_queries.txt
    	
    	echo                                                      >> $target_dir/drv_cfg_queries.txt
    	echo query_guid:                                          >> $target_dir/drv_cfg_queries.txt
    	$install_full_path/bin/drv_cfg --query_guid               >> $target_dir/drv_cfg_queries.txt
        
    fi

}

#################################################
# CallHome functions
#################################################

#################################################
# Dump callhome info
callhome_dump_info()
{
    proc_full_name=$2
    target_dir="$1/$proc_full_name" # /tmp/$COMPANY-getinfo-tmp-dir
    proc_base_name=$2

    install_full_path="$COMP_INS_PATH/$proc_full_name"

    if [ ! -d $install_full_path ]; then
    	return 0
    fi

    proc_real_name=`cat $COMP_INS_PATH/$proc_full_name/bin/daemon`

    # Create a directory
    \mkdir -p $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    echo "Gathering information from $install_full_path"
	if [ $EXCEPTIONS_ONLY -eq 1 ]; then
		get_exception_files $install_full_path $target_dir
		return 0
	fi
    # Get logs and exception file
    get_logs_dir $install_full_path $target_dir
    get_cfg_dir  $install_full_path $target_dir

    process_pid=$($PIDOF_BIN -x $proc_real_name)
    if [ $? -ne 0 ]; then
	    print_error $target_dir "$proc_base_name installed but not running"
    fi
}

#################################################
# Lia functions
#################################################

#################################################
# Dump lia info
lia_dump_info()
{
    proc_full_name=$2
    target_dir="$1/$proc_full_name" # /tmp/$COMPANY-getinfo-tmp-dir
    proc_base_name=$2

    install_full_path="$COMP_INS_PATH/$proc_full_name"

    if [ ! -d $install_full_path ]; then
    	return 0
    fi

    proc_real_name=`cat $COMP_INS_PATH/$proc_full_name/bin/daemon`

    # Create a directory
    \mkdir -p $target_dir
    if [ $? -ne 0 ]; then
       echo "Unable to create temporary directory $target_dir" | \tee /dev/stderr
       exit 555
    fi

    echo "Gathering information from $install_full_path"
	if [ $EXCEPTIONS_ONLY -eq 1 ]; then
		get_exception_files $install_full_path $target_dir
		return 0
	fi
    # Get logs and exception file
    get_logs_dir $install_full_path $target_dir
    get_cfg_dir  $install_full_path $target_dir
    get_bin_file $install_full_path $target_dir $proc_real_name
    get_core_files $install_full_path $target_dir $proc_real_name
	get_vgcore_files $install_full_path $target_dir $proc_real_name

    process_pid=$($PIDOF_BIN -x $proc_real_name)

    if [ $? -ne 0 ]; then
	    print_error $target_dir "$proc_base_name installed but not running"
    fi
}

#################################################
# Help & paramters

usage()
{
    cat << DOCUMENT

    ========================================================================
    THE FOLLOWING TOOL MAY BE USED BY EMC-ScaleIO CERTIFIED TECHNICIAN ONLY!
    ========================================================================

    Usage: get_info.sh [-help | Options]

    Description:
                This tool is a debug utility which allows a technician to collect debug
                information and send it back to ScaleIO support for further analysis.

    Parameters:
        -h, --help
                Display help documentation

    Options:
        -d <PATH>
                Specify the path to receive all the collected information
        -c
                Generate SDS and/or MDM core dump. Available only when one (or more) of the components is running

        -r
                Collect repository files
        -e
                Collect exception files only
        -l
                lite version. Copy only trc.0 and exp.0 from the logs directory and repository files.
                
        -u <USER NAME>
                User name. used to perform a login, must be supplied with a password.
                
        -p <PASSWORD>
                Password. used to perform a login, must be supplied with a user name.
        -b
                Collect MDM, SDS, LIA binaries and core dumps.
        -g
                Collect MDM, SDS, LIA binaries and valgrind core dumps.
        -s
                Collect SDBG output
        -f
                Skip querying CLI info (whenever you don't have credentials    
        -a
                Collect all info
        -n
                Connect to the MDM in nonsecure mode

DOCUMENT
}

# Parse the command line parameters
while getopts ":p:u:d:rhcelbsfan" options; do
    case "${options}" in
	p)	if [ "$OPTARG" = "" ]; then
			echo Missing password | \tee /dev/stderr
			usage
			exit 556
		fi
		PASSWORD=$OPTARG
		;;
	u)	if [ "$OPTARG" = "" ]; then
			echo Missing username | \tee /dev/stderr
			usage
			exit 556
                    fi
		USERNAME=$OPTARG
		;;
	d)	if [ "$OPTARG" = "" ]; then
			echo Missing output path | \tee /dev/stderr
			usage
			exit 556
		fi
		OUT_TARGET_PATH=$OPTARG
		;;
	c)	GENERATE_TGT_CORE=1
		GENERATE_MDM_CORE=1
		;;
	r)	COPY_REP_FILES=1
			;;
	e)		EXCEPTIONS_ONLY=1
			;;
	h)		usage
			exit 0
			;;
	l)		LIGHT_VERSION=1
			;;
	b)		COPY_CORE_DUMPS=2
            COPY_BINARIES=1
			;;
	g)		COPY_VGCORE_DUMPS=2
            COPY_BINARIES=1
			;;
	s)		EXTRACT_SDBG=1
			;;
    f)      FORCE_NOT_CONNECT=1
            ;;
    a)      COPY_REP_FILES=1
            COPY_CORE_DUMPS=2
            COPY_BINARIES=1
            EXTRACT_SDBG=1
            ;;
    n)      SECURITY="--use_nonsecure_communication"
            ;;
	*)		usage
			exit 360
			;;
	esac
done

        
#################################################
# Main code

# Clean temporary directory
clean_tmp_dir

# Did we get any login information?
if [ ! -z $USERNAME ] || [ ! -z $PASSWORD ] ; then
	# Verify both user and password were given
    if [ -z $USERNAME ] || [ -z $PASSWORD ] ; then
        echo To login both user-name and password must be specified | \tee /dev/stderr
        usage
        exit 556
    else
    	# Is the mdm even present?
		if [ -d ${COMP_INS_PATH}/${MDM_DIR_NAME}/bin ]; then
			# If login was requested, verify its result
			run_cli_cmd --login --username $USERNAME --password $PASSWORD 2>/dev/null
			RET=$?
			if [ $RET -ne 0 ] ; then
				echo Login failed. | \tee /dev/stderr
                if [ ! $FORCE_NOT_CONNECT -eq 1 ] && [ $RET -eq 8 ]; then
                    echo Exiting... to force failed login use -f
                    exit 360
                fi
			else
				echo Successfuly logged in.
	        fi
    	else
    		echo MDM is not present, skipping login
    	fi
    fi
fi

if [ -z $USERNAME ] && [ ! $FORCE_NOT_CONNECT -eq 1 ] && [ -d ${COMP_INS_PATH}/${MDM_DIR_NAME}/bin ]; then
    echo You must provide user and password when the mdm is installed
    echo To suppress this message use the option -f
    exit 556
fi

# Trap interrupt signals.  From now on we don't want to leave leftovers
trap handle_interrupt EXIT INT TERM

\mkdir -p $TMP_TARGET_PATH
if [ $? -ne 0 ]; then
   echo "Unable to create directory $TMP_TARGET_PATH" | \tee /dev/stderr
   exit 555
fi

echo Cleaning $OUT_TARGET_PATH
\rm -rf $OUT_TARGET_PATH

if [ $EXCEPTIONS_ONLY -eq 0 ]; then
	# Server parameters
	get_server_info $TMP_TARGET_PATH
fi
# TB parameters
tb_dump_info $TMP_TARGET_PATH tb

# MDM parameters
mdm_dump_info $TMP_TARGET_PATH mdm

# SDS parameters
tgt_dump_info $TMP_TARGET_PATH sds sds

for sdsIndex in {1..20}
do
  tgt_dump_info $TMP_TARGET_PATH sds$sdsIndex sds
done

if [ $EXCEPTIONS_ONLY -eq 0 ]; then
	# SDC parameters
	ini_dump_info $TMP_TARGET_PATH sdc
fi

#callhome info
callhome_dump_info $TMP_TARGET_PATH callhome

#lia_info
lia_dump_info $TMP_TARGET_PATH lia

if [ $EXCEPTIONS_ONLY -eq 0 ]; then
	# Copy also extra files
	echo "Any file located in $EXT_TARGET_PATH, will also be copied and zipped"
	if [ -d $EXT_TARGET_PATH ]; then
		\mv $EXT_TARGET_PATH $TMP_TARGET_PATH/
		echo "$EXT_TARGET_PATH deleted"
	fi
fi

# Tar & zip
zip_and_tar_all $OUT_TARGET_PATH getInfoDump $TMP_TARGET_PATH

# Clean temporary directory
trap - EXIT INT TERM
clean_tmp_dir
exit 0

